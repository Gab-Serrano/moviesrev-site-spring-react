package dev.devdrilo.moviesrev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesrevApplicationTests {

	@Test
	void contextLoads() {
	}

}
